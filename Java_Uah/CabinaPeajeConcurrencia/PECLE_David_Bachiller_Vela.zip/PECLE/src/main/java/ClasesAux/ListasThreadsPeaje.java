/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesAux;

import Hilos.Ambulancia;
import Hilos.Camion;
import Hilos.Coche;
import Hilos.Empleado;
import java.util.ArrayList;
import javax.swing.JTextField;

/**
 *
 * @author david
 */
public class ListasThreadsPeaje {
    ArrayList<Coche> coche;
    ArrayList<Camion> camion;
    ArrayList<Ambulancia> ambulancia;
    ArrayList<Empleado> empleado;
    JTextField tf;

    public ListasThreadsPeaje(JTextField tf) {
        this.tf = tf;
        ambulancia=new ArrayList<Ambulancia>();
        camion=new ArrayList<Camion>();
        empleado = new ArrayList<Empleado>() ;
        coche=new ArrayList<Coche>();
    }
    
    public synchronized void meter(Camion n)
    {
        camion.add(n);
        imprimirC();
    }

   

    public synchronized void sacar(Camion n)
    {
        camion.remove(n);
        imprimirC();
    }

  
    public void imprimirC()
    {
        String contenido="";
        for(int i=0; i<camion.size(); i++)
        {
           contenido=contenido+camion.get(i).getIdCamion()+" ";
        }
        tf.setText(contenido);
    }
    
    public void limpiar(Camion c){
        for(int i = 0; i<camion.size(); i++){
            sacar(c);
            imprimirC();
        }
    }
    
    public synchronized void meter(Ambulancia n)
    {
        ambulancia.add(n);
        imprimirA();
    }

   

    public synchronized void sacar(Ambulancia n)
    {
        ambulancia.remove(n);
        imprimirA();
    }

  
    public void imprimirA()
    {
        String contenido="";
        for(int i=0; i<ambulancia.size(); i++)
        {
           contenido=contenido+ambulancia.get(i).getIdAmbulancia()+" ";
        }
        tf.setText(contenido);
    }
    
    public void limpiar(Ambulancia c){
        for(int i = 0; i<ambulancia.size(); i++){
            sacar(c);
            imprimirA();
        }
    }
    
    public synchronized void meter(Empleado n)
    {
        empleado.add(n);
        imprimirE();
    }

   

    public synchronized void sacar(Empleado n)
    {
        empleado.remove(n);
        imprimirE();
    }

  
    public void imprimirE()
    {
        String contenido="";
        for(int i=0; i<empleado.size(); i++)
        {
           contenido=contenido+empleado.get(i).getIdEmpleado()+" ";
        }
        tf.setText(contenido);
    }
    
    public void limpiar(Empleado c){
        for(int i = 0; i<empleado.size(); i++){
            sacar(c);
            imprimirE();
        }
    }
 
     public synchronized void meter(Coche n)
    {
        coche.add(n);
        imprimir();
    }

   

    public synchronized void sacar(Coche n)
    {
        coche.remove(n);
        imprimir();
    }

  
    public void imprimir()
    {
        String contenido="";
        for(int i=0; i<coche.size(); i++)
        {
           contenido=contenido+coche.get(i).getIdCoche()+" ";
        }
        tf.setText(contenido);
    }
    
    public void limpiar(Coche c){
        for(int i = 0; i<coche.size(); i++){
            sacar(c);
            imprimir();
        }
    }

}
