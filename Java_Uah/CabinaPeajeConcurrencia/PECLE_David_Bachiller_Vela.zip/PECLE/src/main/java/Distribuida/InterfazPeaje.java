/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Distribuida;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author david
 */
public interface InterfazPeaje extends Remote{
    void cierraCabinaCoche4() throws RemoteException;
    void abreCabinaCoche4() throws RemoteException;
    void cierraCabinaCoche5() throws RemoteException;
    void abreCabinaCoche5() throws RemoteException;
    void cierraCabinaCoche6() throws RemoteException;
    void abreCabinaCoche6() throws RemoteException;
    void cierraCabinaCamion3() throws RemoteException;
    void abreCabinaCamion3() throws RemoteException;
    void cierraCabinaCamion4() throws RemoteException;
    void abreCabinaCamion4() throws RemoteException;
    String devuelveContenidoJTextFields(String cuadroDeTexto) throws RemoteException;
}
