/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Distribuida;

import Concurrencia.CabinaPeaje;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author david
 */
public class Gestor extends UnicastRemoteObject implements InterfazPeaje {
    private CabinaPeaje cb;

    public Gestor(CabinaPeaje cb) throws RemoteException {
        this.cb = cb;
    }
    
    @Override
    public void cierraCabinaCoche4(){
        cb.cierraCabinas("CabinaCoches4");
    }
    
    @Override
    public void abreCabinaCoche4(){
        
        cb.abreCabinas("CabinaCoches4");
    }
   
    @Override
    public void cierraCabinaCoche5(){
        cb.cierraCabinas("CabinaCoches5");
    }

    @Override
    public void abreCabinaCoche5(){
        
        cb.abreCabinas("CabinaCoches5");
    }
  
    @Override
    public void cierraCabinaCoche6(){
        cb.cierraCabinas("CabinaCoches6");
    }
   
    @Override
    public void abreCabinaCoche6(){
        
        cb.abreCabinas("CabinaCoches6");
    }
    
    @Override
    public void cierraCabinaCamion3(){
        cb.cierraCabinas("CabinaCamiones3");
    }
    
    @Override
    public void abreCabinaCamion3(){
        
        cb.abreCabinas("CabinaCamiones3");
    }

    public void cierraCabinaCamion4(){
        cb.cierraCabinas("CabinaCamiones4");
    }

    @Override
    public void abreCabinaCamion4(){
       
        cb.abreCabinas("CabinaCamiones4");
    }
    public String devuelveContenidoJTextFields(String contenidoC){
        String contenido = "";
        switch (contenidoC) {
            case "colaEntradaPeaje":
                contenido = cb.getColaEntradaPeaje().getText();
                break;
            case "cocheCabina1M1":
                contenido = cb.getCocheCabina1M1().getText();
                break;
            case "cocheCabina2M":
                contenido = cb.getCocheCabina2M().getText();
                break;
            case "cocheCabina3M":
                contenido = cb.getCocheCabina3M().getText();
                break;
            case "cocheCabina4T":
                contenido = cb.getCocheCabina4T().getText();
                break;
            case "cocheCabina5T1":
                contenido = cb.getCocheCabina5T1().getText();
                break;
            case "cocheCabina6T":
                contenido = cb.getCocheCabina6T().getText();
                break;
            case "camionCabina1M":
                contenido = cb.getCamionCabina1M().getText();
                break;
            case "camionCabina2M":
                contenido = cb.getCamionCabina2M().getText();
                break;
            case "camionCabina3T1":
                contenido = cb.getCamionCabina3T1().getText();
                break;
            case "camionCabina4T":
                contenido = cb.getCamionCabina4T().getText();
                break;
            case "EmpleadoCabinaCoches1M":
                contenido = cb.getEmpleadoCabinaCoches1M().getText();
                break;
            case "EmpleadoCabinaCoches2M":
                contenido = cb.getEmpleadoCabinaCoches2M().getText();
                break;
            case "EmpleadoCabinaCoches3M":
                contenido = cb.getEmpleadoCabinaCoches3M().getText();
                break;
            case "EmpleadoCabinaCamiones1M":
                contenido = cb.getEmpleadoCabinaCamiones1M().getText();
                break;
            case "EmpleadoCabinaCamiones2M":
                contenido = cb.getEmpleadoCabinaCamiones2M().getText();
                break;
            default:
                break;
        }
        return contenido;
    }

    public CabinaPeaje getCb() {
        return cb;
    }
    
    
}
