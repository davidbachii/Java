/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Concurrencia;



import ClasesAux.ListasThreadsPeaje;
import Hilos.Ambulancia;
import Hilos.Camion;
import Hilos.Coche;
import Hilos.Empleado;
import Log.FuncionesLog;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.*;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javax.management.Query.or;
import javax.swing.JTextField;

/**
 *
 * @author david
 */

public class CabinaPeajeManual extends Cabina{
    private JTextField vehiculo;
    private JTextField empleado;
    private ListasThreadsPeaje empleados, coches, camiones,ambulancia;
    private FuncionesLog fg;
    private int i;
    private boolean accesoCoche = true;
    private boolean accesoCamion = true;
    private boolean cocheEsperando = false;
    private boolean camionEsperando = false;
    private boolean ambulanciaEsperando = false;
    private boolean empleadoEsperando = false;
    
    
    //Concurrencia
    Lock lock = new ReentrantLock();
    Condition esperaEmpleado = lock.newCondition();
    Condition esperaCoche = lock.newCondition();
    Condition esperaCamion = lock.newCondition();
    Condition esperaAmbulancia = lock.newCondition();
    Condition cd = lock.newCondition();
    Condition cd2 = lock.newCondition();
    
    

    public CabinaPeajeManual(String nombre,JTextField vehiculo, JTextField empleado, FuncionesLog fg, int i) {
        super(nombre,"Manual");
        this.fg = fg;
        this.vehiculo = vehiculo;
        coches = new ListasThreadsPeaje(vehiculo);
        camiones = new ListasThreadsPeaje(vehiculo);
        ambulancia = new ListasThreadsPeaje(vehiculo);
        this.empleado = empleado;
        empleados = new ListasThreadsPeaje(empleado);
        this.i = i;
    }
    
    public void entradaEmpleadosCabinas(Empleado e){
   lock.lock();
   try{
        empleados.meter(e);
        fg.writeDebugFile("El "+e.getIdEmpleado()+" accede a la cabina de peaje "+i+"\n");
        if(!isCocheEsperando() || !isCamionEsperando() || !isAmbulanciaEsperando()){
            setEmpleadoEsperando(true);
            try{
               esperaEmpleado.await();
            }catch(InterruptedException ar){
                System.out.println(ar.toString());
            }
        }
   
   }finally{
       lock.unlock();
   }
        
    }
    
    public void salidaEmpleadoDescanso(Empleado e) throws InterruptedException{
       
        lock.lock();
        try{
        empleados.sacar(e);
        fg.writeDebugFile("El "+e.getIdEmpleado()+" comienza su descanso en la cabina "+i+"\n");
        Thread.sleep(5000);
        fg.writeDebugFile("El "+e.getIdEmpleado()+" finaliza su descanso en la cabina "+i+"\n");
        setEmpleadoEsperando(false);
        }finally{
            lock.unlock();
        }   
    }
    public void vueleveEmpleado(Empleado e){
        lock.lock();
        try{
            if(!isCocheEsperando() ){
                setEmpleadoEsperando(true);
                try{
                    esperaEmpleado.await();
                }catch(InterruptedException a){
                    System.out.println(a.toString());
                }
            }
        }finally{
            lock.unlock();
        }
    }

    
      
   

    public void entradaCabinasCoches(Coche coche){
       
        lock.lock();
        try{
            
            coches.meter(coche);
            fg.writeDebugFile("El "+coche.getIdCoche()+" accede a la cabina de peaje "+i+"\n");
            accesoCoche = false;
            if(isEmpleadoEsperando()){
                esperaEmpleado.signal();
            }else{
                setCocheEsperando(true);
            }
            try{
               esperaCoche.await();
            }catch(InterruptedException e){
                System.out.println(e.toString());
            }
            
        }finally{
            lock.unlock();
        }
        
    }
    public void entradaCabinasAmbulancia(Ambulancia a){
      lock.lock();
        try{
            
            ambulancia.meter(a);
            fg.writeDebugFile("La "+a.getIdAmbulancia()+" accede a la cabina de peaje "+i+"\n");
            if(isEmpleadoEsperando()){
                esperaEmpleado.signal();
            }else{
                setAmbulanciaEsperando(true);
            }
            try{
               esperaAmbulancia.await();
            }catch(InterruptedException e){
                System.out.println(e.toString());
            }
            
        }finally{
            lock.unlock();
        }
         
    }
    public void pagoAmbulancia(Empleado e) throws InterruptedException{
        lock.lock();
        try{
            fg.writeDebugFile("El empleado "+e.getIdEmpleado()+" esta cobrando a la ambulancia en la cabina "+i+"\n");
            Thread.sleep((int) (Math.random() * 8000 + 6000));
            setAmbulanciaEsperando(false);
            esperaAmbulancia.signal();
            e.setActividadesSeguidas(e.getActividadesSeguidas()+1);
        }finally{
            lock.unlock();
        }
    }
    public void realizarPagoCoches(Empleado e) throws InterruptedException{
       
       lock.lock();
       try{
       fg.writeDebugFile("El empleado "+e.getIdEmpleado()+" esta cobrando al coche en la cabina "+i+"\n");
       Thread.sleep((int) (Math.random() * 8000 + 6000));
        setCocheEsperando(false);
        esperaCoche.signal();
        e.setActividadesSeguidas(e.getActividadesSeguidas()+1);
    }finally{
    lock.unlock();
}
       
    }
     public void realizarPagoCamiones(Empleado e) throws InterruptedException{
       
       lock.lock();
       try{
       fg.writeDebugFile("El empleado "+e.getIdEmpleado()+" esta cobrando al camion en la cabina "+i+"\n");
       Thread.sleep((int) (Math.random() * 8000 + 6000));
        setCamionEsperando(false);
        esperaCamion.signal();
        e.setActividadesSeguidas(e.getActividadesSeguidas()+1);
    }finally{
    lock.unlock();
}
    }
    public void salidaCoche(Coche coche){
        coches.sacar(coche);
        fg.writeDebugFile("El "+coche.getIdCoche()+" sale de la cabina de peaje de vuelta a la carretera \n");      
        accesoCoche = true;
    }
    public void cocheCabinaManual(Coche coche){
        lock.lock();
        try{
        entradaCabinasCoches(coche);
        coche.getPaso().mirar();
        salidaCoche(coche);
    }finally{
    lock.unlock();
}
    }

    public void entradaCabinasCamiones(Camion camion){
      lock.lock();
        try{
            
            camiones.meter(camion);
            fg.writeDebugFile("El "+camion.getIdCamion()+" accede a la cabina de peaje "+i+"\n");
            accesoCamion = false;
            if(isEmpleadoEsperando()){
                esperaEmpleado.signal();
            }else{
                setCamionEsperando(true);
            }
            try{
               esperaCamion.await();
            }catch(InterruptedException e){
                System.out.println(e.toString());
            }
            
        }finally{
            lock.unlock();
        }
         
    }
     public void salidaCamion(Camion camion){
        camiones.sacar(camion);
        fg.writeDebugFile("El "+camion.getIdCamion()+" sale de la cabina de peaje de vuelta a la carretera \n");      
       accesoCamion = true;
    }
    public void camionCabinaManual(Camion camion){
        lock.lock();
        try{
        entradaCabinasCamiones(camion);
        camion.getPaso().mirar();
        salidaCamion(camion);
    }finally{
    lock.unlock();
}
    }
    
    
     public void salidaAmbulancia(Ambulancia am){
        ambulancia.sacar(am);
        fg.writeDebugFile("La "+am.getIdAmbulancia()+" sale de la cabina de peaje de vuelta a la carretera \n");      
    }
    public void ambulanciaCabinaManual(Ambulancia am){
        lock.lock();
        try{
        entradaCabinasAmbulancia(am);
        salidaAmbulancia(am);
    }finally{
    lock.unlock();
}
    }

   

    public boolean isCocheEsperando() {
        return cocheEsperando;
    }

    public void setCocheEsperando(boolean cocheEsperando) {
        this.cocheEsperando = cocheEsperando;
    }

    public boolean isCamionEsperando() {
        return camionEsperando;
    }

    public void setCamionEsperando(boolean camionEsperando) {
        this.camionEsperando = camionEsperando;
    }

    public boolean isEmpleadoEsperando() {
        return empleadoEsperando;
    }

    public void setEmpleadoEsperando(boolean empleadoEsperando) {
        this.empleadoEsperando = empleadoEsperando;
    }

    public boolean isAmbulanciaEsperando() {
        return ambulanciaEsperando;
    }

    public void setAmbulanciaEsperando(boolean ambulanciaEsperando) {
        this.ambulanciaEsperando = ambulanciaEsperando;
    }

  
   
 
    
    
    
   
    
}
