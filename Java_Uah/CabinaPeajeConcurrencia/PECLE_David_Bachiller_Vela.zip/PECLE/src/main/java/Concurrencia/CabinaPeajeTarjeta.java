/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Concurrencia;



import ClasesAux.ListasThreadsPeaje;
import Hilos.Ambulancia;
import Hilos.Camion;
import Hilos.Coche;
import Hilos.Empleado;
import Log.FuncionesLog;
import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import javax.swing.JTextField;

/**
 *
 * @author david
 */
public class CabinaPeajeTarjeta extends Cabina {
    private boolean abierta = true;
    private JTextField vehiculo;
    private ListasThreadsPeaje coches, camiones, ambulancia;
    private FuncionesLog fg;
    private boolean accesoCoche = true;
    private boolean accesoCamion = true;
    private boolean accesoAmbulancia = true;
    private int i;
    Lock lock = new ReentrantLock();
    

    public CabinaPeajeTarjeta(String nombre,JTextField vehiculo, FuncionesLog fg, int i) {
        super(nombre,"Tarjeta");
        this.vehiculo = vehiculo;
        this.fg = fg;
        this.i = i;
        coches = new ListasThreadsPeaje(vehiculo);
        camiones = new ListasThreadsPeaje(vehiculo);
        ambulancia = new ListasThreadsPeaje(vehiculo);
    }
    
    
  

    
     public void entradaCabinasCamiones(Camion camion){
       Random r = new Random();
        lock.lock();
        try{
            camiones.meter(camion);
            fg.writeDebugFile("El "+camion.getIdCamion()+" accede a la cabina de peaje "+i+"\n");

        }finally{
            lock.unlock();
        }
         
    }
      public void pagoCabinasCamiones(Camion camion) throws InterruptedException{
       Random r = new Random();
        lock.lock();
        try{
            
            fg.writeDebugFile("El "+camion.getIdCamion()+" esta pagando en la cabina de peaje "+i+"\n");
            Thread.sleep((int)(Math.random() * 8000 + 6000)); 
        }finally{
            lock.unlock();
        }
         
    }
       public void salidaCabinasCamiones(Camion camion){
       Random r = new Random();
        lock.lock();
        try{
            camiones.sacar(camion);
            fg.writeDebugFile("El "+camion.getIdCamion()+" sale de la cabina de peaje "+i+"\n");

        }finally{
            lock.unlock();
        }
         
    }
       
     
     public void entradaCabinaCoches(Coche cc){
       Random r = new Random();
        lock.lock();
        try{
           accesoCoche = false;
            coches.meter(cc);
            fg.writeDebugFile("El "+cc.getIdCoche()+" accede a la cabina de peaje "+i+"\n");
            Thread.sleep(6000+r.nextInt(8000));
            cc.getPaso().mirar();
            coches.sacar(cc);
            fg.writeDebugFile("El "+cc.getIdCoche()+" sale de la cabina de peaje de vuelta a la carretera\n");
            accesoCoche = true;
            
            
        }catch(InterruptedException e){
            System.out.println(e.toString());
        }finally{
            lock.unlock();
        }
         
    }
     
      public void entradaCabinaAmbulancia(Ambulancia a){
       Random r = new Random();
        lock.lock();
        try{
           accesoAmbulancia = false;
            ambulancia.meter(a);
            fg.writeDebugFile("La "+a.getIdAmbulancia()+" accede a la cabina de peaje "+i+"\n");
            
            Thread.sleep(6000+r.nextInt(8000)); 
            ambulancia.sacar(a);
            fg.writeDebugFile("La "+a.getIdAmbulancia()+" sale de la cabina de peaje de vuelta a la carretera\n");
            accesoAmbulancia = true;
            
            
        }catch(InterruptedException e){
            System.out.println(e.toString());
        }finally{
            lock.unlock();
        }
         
    }

    

    public boolean isAbierta() {
        return abierta;
    }

    public void setAbierta(boolean abierta) {
        this.abierta = abierta;
    }

  
    
   
  
}
