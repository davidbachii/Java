/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Concurrencia;

import Hilos.Coche;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * @author david
 */
public class Paso {
   private boolean cerrado = false;
    private Lock cerrojo = new ReentrantLock();
    private Condition parar = cerrojo.newCondition();

    //Métodos de la clase paso

    //Método constructor
    public Paso(){

    }
    //Método que mira si nos tenemos que detener o no
    public void mirar() {
        try {
            cerrojo.lock();
            while(isCerrado()) {
                try {
                    parar.await();
                } catch(InterruptedException ie){ }
            }
        }
        finally {
            cerrojo.unlock();
        }
    }
    //Método para reanudar ejecucion de hilos
    public void abrir() {
        try{
            cerrojo.lock();
            setCerrado(false);
            parar.signalAll();
        }
        finally {
            cerrojo.unlock();
        }
    }
    //Métodos para reanuar ejecucion de hilos
    public void cerrar() {
        try{
            cerrojo.lock();
            setCerrado(true);
        }
        finally
        {
            cerrojo.unlock();
        }
    }

    public boolean isCerrado() {
        return cerrado;
    }

    public void setCerrado(boolean cerrado) {
        this.cerrado = cerrado;
    }
}
