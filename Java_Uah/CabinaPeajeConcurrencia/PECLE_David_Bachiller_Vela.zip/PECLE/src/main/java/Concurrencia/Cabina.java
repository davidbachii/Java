/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Concurrencia;

/**
 *
 * @author david
 */
public class Cabina {
    private String nombreCabina = "";
    private String tipo = "";
    private boolean disponible = true;

    public Cabina(String nombre, String tipo) {
        
        this.nombreCabina = nombre;
        this.tipo = tipo;
    }

    public String getNombreCabina() {
        return nombreCabina;
    }

    public void setNombreCabina(String nombreCabina) {
        this.nombreCabina = nombreCabina;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }
    
    
    
    
}
