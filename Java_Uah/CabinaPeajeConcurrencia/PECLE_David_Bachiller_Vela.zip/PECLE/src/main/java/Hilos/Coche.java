/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hilos;

import Concurrencia.CabinaPeaje;
import Concurrencia.CabinaPeajeManual;
import Concurrencia.CabinaPeajeTarjeta;
import Concurrencia.Paso;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author david
 */
public class Coche extends Thread{
    
    private String id;
    private CabinaPeaje cabinapeaje;
    private CabinaPeajeManual cab = null;
    private CabinaPeajeTarjeta cpt =  null;
    
    private Paso paso;
    
    public Coche(int id, CabinaPeaje cb,Paso paso){
        this.id = "Coche"+id;
        this.cabinapeaje = cb;
      
        this.paso = paso;
    }

    
    @Override
    public void run(){
        cabinapeaje.getPaso().mirar();
        cabinapeaje.entradaColaPeajeCoche(this);
        
        if(this.getCab()!= null){
            //Comprobamos que ha entrado a una cabina manual
            cabinapeaje.getPaso().mirar();
            getCab().cocheCabinaManual(this);
        }
        else{
            //Comprobamos que ha entrado a una cabina automática
            cabinapeaje.getPaso().mirar();
            getCpt().entradaCabinaCoches(this);
            
            
        }
        //Una vez que hemos salido de la cabina, nos saldremos del peaje
        cabinapeaje.getPaso().mirar();
        cabinapeaje.salidaPeajeCoche(this);
        
    }

   

    public CabinaPeajeManual getCab() {
        return cab;
    }

    public void setCpt(CabinaPeajeTarjeta cpt) {
        this.cpt = cpt;
    }

    public void setCab(CabinaPeajeManual cab) {
        this.cab = cab;
    }

    public Paso getPaso() {
        return paso;
    }

    public void setPaso(Paso paso) {
        this.paso = paso;
    }

    public CabinaPeajeTarjeta getCpt() {
        return cpt;
    }

   
    
    
    
    
    
    
    
    
    
    
    
    public String getIdCoche() {
        return id;
    }

    public CabinaPeaje getCabinapeaje() {
        return cabinapeaje;
    }
    
    
    
}
