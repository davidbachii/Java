/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hilos;

import Concurrencia.CabinaPeaje;
import Concurrencia.CabinaPeajeManual;
import Concurrencia.CabinaPeajeTarjeta;
import Concurrencia.Paso;
import java.util.Random;

/**
 *
 * @author david
 */
public class Ambulancia extends Thread {
    private String id;
    private CabinaPeaje cabinapeaje;
    private CabinaPeajeManual cpm = null;
    private CabinaPeajeTarjeta cpt = null;
    private Paso paso;
    
    public Ambulancia(int id, CabinaPeaje cb, Paso paso){
        this.id = "Ambulancia"+id;
        this.cabinapeaje = cb;
        this.paso = paso; 
    }

    
    
    
    @Override
    public void run() {
        cabinapeaje.getPaso().mirar();
        cabinapeaje.entradaColaPeajeAmbulancia(this);
        
        if(this.getCpm()!= null){
            //Comprobamos que ha entrado a una cabina manual
            cabinapeaje.getPaso().mirar();
            getCpm().ambulanciaCabinaManual(this);
        }
        else{
            //Comprobamos que ha entrado a una cabina automática
            cabinapeaje.getPaso().mirar();
            getCpt().entradaCabinaAmbulancia(this);
            
            
        }
        //Una vez que hemos salido de la cabina, nos saldremos del peaje
        cabinapeaje.getPaso().mirar();
        cabinapeaje.salidaPeajeAmbulancia(this);
        
    }
        
    
    
    
    
    public String getIdAmbulancia() {
        return id;
    }

    public CabinaPeaje getCabinapeaje() {
        return cabinapeaje;
    }

    public CabinaPeajeManual getCpm() {
        return cpm;
    }

    public void setCpm(CabinaPeajeManual cpm) {
        this.cpm = cpm;
    }

    public CabinaPeajeTarjeta getCpt() {
        return cpt;
    }

    public void setCpt(CabinaPeajeTarjeta cpt) {
        this.cpt = cpt;
    }
    
    
}
