/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hilos;

import Concurrencia.CabinaPeaje;
import Concurrencia.CabinaPeajeManual;
import Concurrencia.CabinaPeajeTarjeta;
import Concurrencia.Paso;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author david
 */
public class Camion extends Thread{
    private String id;
    private CabinaPeaje cabinapeaje;
    private CabinaPeajeManual cpm = null;
    private CabinaPeajeTarjeta cpt = null;
    
    private Paso paso;
  
    
    
    public Camion(int id, CabinaPeaje cb, Paso paso){
        this.id = "Camion"+id;
        this.cabinapeaje = cb;
        this.paso = paso;
        
        
    }
    
    @Override
    public void run(){
        cabinapeaje.getPaso().mirar();
        cabinapeaje.entradaColaPeajeCamion(this);
        
        if(this.getCpm()!= null){
            //Comprobamos que ha entrado a una cabina manual
            cabinapeaje.getPaso().mirar();
            getCpm().camionCabinaManual(this);
        }
        else{
            //Comprobamos que ha entrado a una cabina automática
            cabinapeaje.getPaso().mirar();
            getCpt().entradaCabinasCamiones(this);
            
            try {
                cabinapeaje.getPaso().mirar();
                getCpt().pagoCabinasCamiones(this);
            } catch (InterruptedException ex) {
                Logger.getLogger(Camion.class.getName()).log(Level.SEVERE, null, ex);
            }
            cabinapeaje.getPaso().mirar();
            getCpt().salidaCabinasCamiones(this);
            
            
        }
        
        paso.mirar();
        cabinapeaje.salidaPeajeCamiones(this);
    }


    
    
    public String getIdCamion() {
        return id;
    }

    public CabinaPeaje getCabinapeaje() {
        return cabinapeaje;
    }

    public CabinaPeajeTarjeta getCpt() {
        return cpt;
    }

    public CabinaPeajeManual getCpm() {
        return cpm;
    }

    public Paso getPaso() {
        return paso;
    }

    public void setCabinapeaje(CabinaPeaje cabinapeaje) {
        this.cabinapeaje = cabinapeaje;
    }

    public void setCpt(CabinaPeajeTarjeta cpt) {
        this.cpt = cpt;
    }

    public void setCpm(CabinaPeajeManual cpm) {
        this.cpm = cpm;
    }

    
    
    
}
