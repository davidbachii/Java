/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hilos;

import Concurrencia.CabinaPeaje;
import Concurrencia.CabinaPeajeManual;
import Concurrencia.Paso;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author david
 */
public class Empleado extends Thread{
    private String id;
    private CabinaPeajeManual cb;
    private int actividadesSeguidas = 0;
    private Paso paso;
    private CabinaPeaje cabinapeaje;
    
    public Empleado(int id, CabinaPeajeManual cb, Paso paso,CabinaPeaje cabinapeaje){
        this.id = "Empleado"+id;
        this.cb = cb;
        this.paso = paso;
        this.cabinapeaje = cabinapeaje;
    }
    
    @Override
    public void run(){
            cabinapeaje.getPaso().mirar();
            cb.entradaEmpleadosCabinas(this);
            while(true){
                try {
                     cabinapeaje.getPaso().mirar();
                    cb.realizarPagoCoches(this);
                     cabinapeaje.getPaso().mirar();
                    cb.realizarPagoCamiones(this);
                     cabinapeaje.getPaso().mirar();
                    cb.pagoAmbulancia(this);
                    //cb.pagoAmbulancia(this);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Empleado.class.getName()).log(Level.SEVERE, null, ex);
                }
                 cabinapeaje.getPaso().mirar();
                if(getActividadesSeguidas() == 6){
                    try {
                         cabinapeaje.getPaso().mirar();
                        cb.salidaEmpleadoDescanso(this);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Empleado.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    setActividadesSeguidas(0);
                     cabinapeaje.getPaso().mirar();
                    cb.entradaEmpleadosCabinas(this);
                }else{
                     cabinapeaje.getPaso().mirar();
                    cb.vueleveEmpleado(this);
                }
            }
    
        
    }

    public String getIdEmpleado() {
        return id;
    }

    public CabinaPeajeManual getCb() {
        return cb;
    }

    public int getActividadesSeguidas() {
        return actividadesSeguidas;
    }

    public void setActividadesSeguidas(int actividadesSeguidas) {
        this.actividadesSeguidas = actividadesSeguidas;
    }

    public Paso getPaso() {
        return paso;
    }

   
    
    
}
