/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hilos;

import Concurrencia.CabinaPeaje;
import Concurrencia.CabinaPeajeManual;
import Concurrencia.Paso;
import Log.*;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author david
 */
public class CrearCoches extends Thread{
     private final int CAPACIDAD = 50;
     private  CabinaPeaje cabina;
     private  FuncionesLog fg;
   
     
     
     
     
     public CrearCoches(CabinaPeaje cb,FuncionesLog fg){
         this.cabina = cb;
         this.fg = fg; 
      
}
       @Override
     public void run(){
         Random r = new Random();
         for(int i = 0; i< CAPACIDAD ; i++){
             Coche coche = new Coche(i, cabina,cabina.getPaso());
             cabina.getPaso().mirar();
             coche.start();
             try {
                 Thread.sleep(1000+r.nextInt(3000));
             } catch (InterruptedException ex) {
                 Logger.getLogger(CrearCoches.class.getName()).log(Level.SEVERE, null, ex);
             }

         }
     }

    
     
}
